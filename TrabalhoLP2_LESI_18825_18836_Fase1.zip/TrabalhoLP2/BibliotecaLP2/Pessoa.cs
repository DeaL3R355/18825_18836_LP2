﻿namespace BibliotecaLP2
{
    public class Pessoa
    {
        private static int contaID = 0;

        #region ESTADO

        private int identificacao;
        private string nome;
        private string regiao;
        private string genero;
        private int idade;
        private bool infetado;

        #endregion ESTADO

        #region CONSTRUTORES

        public Pessoa()
        {
            identificacao = 0;
            nome = "";
            regiao = "";
            genero = "";
            idade = 0;
            bool infetado = false;
        }

        public Pessoa(string nome, string regiao, string genero, int idade, bool infetado)
        {
            contaID++;
            this.identificacao = contaID;
            this.nome = nome;
            this.regiao = regiao;
            this.genero = genero;
            this.idade = idade;
            this.infetado = infetado;
        }

        #endregion CONSTRUTORES

        #region PROPRIEDADES

        public int Identificacao
        {
            get { return identificacao; } /*Metodo set em baixo*/
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public string Regiao
        {
            get { return regiao; }
            set { regiao = value; }
        }

        public string Genero
        {
            get { return genero; }
            set { genero = value; }
        }

        public int Idade
        {
            get { return idade; }
            set { if (value > 0) idade = value; }
        }

        public bool Infetado
        {
            get { return infetado; }
            set { infetado = value; }
        }

        #endregion PROPRIEDADES
    }
}