﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exceptions;
using BibliotecaClassesTF2V2;
using System.Security.Cryptography;
using System.Runtime.Remoting.Messaging;
using System.Security.Policy;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.SqlServer.Server;
using System.IO;
using System.Xml;

namespace Dados
{
    public class Patients
    {
        private static List<Patient> patients_all;
        private static List<Patient> patient_symptoms; 
        private static List<Patient> patient_NOsymptoms;
        private static List<Patient> filtered_list;

        static Patients() /*Por predefinição um construtor static é sempre privado*/
        {
            patients_all = new List<Patient>();
            patient_symptoms = new List<Patient>();
            patient_NOsymptoms = new List<Patient>();
            filtered_list = new List<Patient>();
        }
        public static void Menu()
        { 
            Console.WriteLine("--------------------------- MENU --------------------------- ");
            Console.WriteLine("1 - List all patients");  /*Listar TODOS os pacientes*/
            Console.WriteLine("2 - List patients with symptoms"); /*Listar os pacientes com sintomas*/
            Console.WriteLine("3 - List patients without symptoms"); /*Listar os pacientes sem sintomas*/
            Console.WriteLine("4 - List infected patients");
            Console.WriteLine("5 - Filter infected patients by age");
            Console.WriteLine("6 - Filter infected patients by region");
            Console.WriteLine("7 - Filter infected patients by gender");
            Console.WriteLine("8 - All Patient stats");
            Console.WriteLine("9 - Alter patient symptoms/infected status");
            Console.WriteLine("10 - Insert patient");
            Console.WriteLine("11 - Main menu");
            Console.WriteLine("0 - Sair");
        }

        public static void AskForPatient (Patient patient)
        {
            bool tryagainAGE = true;
            Console.WriteLine("\n ------- CREATING PATIENT -------\n");

            Console.WriteLine("Insert patient's first name: ");
            patient.First_Name = Console.ReadLine();

            Console.WriteLine("Insert patient's last name: ");
            patient.Last_Name = Console.ReadLine();
            
            Console.WriteLine("Insert patient's region: ");
            patient.Region = Console.ReadLine();

            #region patient.Age 

            while (tryagainAGE == true)
            {
                try
                {
                    tryagainAGE = false;
                    Console.WriteLine("Insert patient's age: ");
                    patient.Age = Convert.ToInt32(Console.ReadLine());
                    if (patient.Age < 0)
                    {
                        throw (new AgeIsNegativeException());
                    }
                }
                catch (AgeIsNegativeException)
                {
                    tryagainAGE = true;
                    Console.WriteLine("\nERROR: Age can not be a negative number. \nPlease enter a valid age.\n");
                }
                catch (FormatException)
                {
                    tryagainAGE = true;
                    Console.WriteLine("Please enter a valid age");
                }
                catch (Exception e)
                {
                    tryagainAGE = false;
                    Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    Environment.Exit(0);
                } 
            }
            #endregion

            #region Patient.Gender

            bool tryagainGender = true;
            while (tryagainGender == true)
            {
                try
                {
                    Console.WriteLine("Insert patient's gender (male/female)");

                    string gender_answer = Console.ReadLine().ToLower().Trim();
                    if (gender_answer == "male")
                    {
                        patient.Gender = EGender.MALE;
                        tryagainGender = false;
                    }
                    else if (gender_answer == "female")
                    {
                        patient.Gender = EGender.FEMALE;
                        tryagainGender = false;
                    }
                    else
                    {
                        throw (new InvalidGenderException());
                    }
                }
                catch (InvalidGenderException)
                {
                    tryagainGender = true;
                    Console.WriteLine("Please insert a valid gender. (male/female)");
                }
                catch (Exception e)
                {
                    tryagainAGE = false;
                    Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    Environment.Exit(0);
                }
            }

            #endregion

            #region Patient.IsInfected

            bool tryagainIsInfected = true;
            while (tryagainIsInfected == true)
            {
                try
                {
                    Console.WriteLine("Is patient infected?: (yes/no)");
                    string infected_answer = Console.ReadLine().ToLower().Trim();
                    if (infected_answer == "yes")
                    {
                        patient.IsInfected = true;
                        tryagainIsInfected = false;
                    }
                    else if (infected_answer == "no")
                    {
                        patient.IsInfected = false;
                        tryagainIsInfected = false;
                    }
                    else
                    {
                        throw (new InvalidOptionBoolAnswerException());
                    }
                }
                catch (InvalidOptionBoolAnswerException)
                {
                    Console.WriteLine("Invalid option. Type (yes or no)");
                    tryagainIsInfected = true;
                }
                catch (Exception e)
                {
                    tryagainIsInfected = false;
                    Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    Environment.Exit(0);
                }
            }

            #endregion

            #region Patient.HasSymptoms

            bool tryagainHasSymptoms = true;
            while (tryagainHasSymptoms == true)
            {
                try
                {
                    Console.WriteLine("Does the patient have symptoms?: (yes/no)");
                    string symptoms_answer = Console.ReadLine().ToLower().Trim();
                    if (symptoms_answer == "yes")
                    {
                        patient.HasSymptoms = true;
                        tryagainHasSymptoms = false;
                    }
                    else if (symptoms_answer == "no")
                    {
                        patient.HasSymptoms = false;
                        tryagainHasSymptoms = false;
                    }
                    else
                    {
                        throw (new InvalidOptionBoolAnswerException());
                    }
                }
                catch (InvalidOptionBoolAnswerException)
                {
                    Console.WriteLine("Invalid option. Type (yes or no)");
                    tryagainHasSymptoms = true;
                }
                catch (Exception e)
                {
                    tryagainHasSymptoms = false;
                    Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    Environment.Exit(0);
                }
            }

            #endregion

            Console.WriteLine("Insert patient's blood type: ");
            patient.Blood_Type = Console.ReadLine();

            #region Patient.Disease
            bool tryagainDisease = true;
            while (tryagainDisease == true)
            {
                try
                {
                    Console.WriteLine("Does the patient have a disease?: (yes/no)");
                    string disease_answer = Console.ReadLine().ToLower().Trim();
                    if (disease_answer == "yes")
                    {
                        Console.WriteLine("Insert patients disease: ");
                        patient.Disease = Console.ReadLine();
                        Console.WriteLine("Insert disease description: ");
                        patient.Disease_Description = Console.ReadLine();
                        tryagainDisease = false;
                    }
                    else if (disease_answer == "no")
                    {
                        patient.Disease = "N/A";
                        patient.Disease_Description = "N/A";
                        tryagainDisease = false;
                    }
                    else
                    {
                        throw (new InvalidOptionBoolAnswerException());
                    }
                }
                catch (InvalidOptionBoolAnswerException)
                {
                    Console.WriteLine("Invalid option. Type (yes or no)");
                    tryagainHasSymptoms = true;
                }
                catch (Exception e)
                {
                    tryagainHasSymptoms = false;
                    Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    Environment.Exit(0);
                }
            }

            #endregion

            SaveAll(patient);
        }

        public static void SaveAll(Patient p)
        {
            patients_all.Add(p);

            string filePath = @"E:\LP2\TrabalhoFase2V2\Patients.txt";

            List<String> output = new List<string>();

            foreach (var item in patients_all)
            {
                output.Add($"{item.First_Name},{item.Last_Name},{item.Region},{item.Age},{item.Gender},{item.IsInfected},{item.HasSymptoms},{item.Disease},{item.Disease_Description}");
            }

            File.WriteAllLines(filePath, output);
        }

        public static void LoadAll()
        {
            string filePath = @"E:\LP2\TrabalhoFase2V2\Patients.txt"; //Caminho onde está guardado o documento de texto


            List<string> file = File.ReadAllLines(filePath).ToList(); //cria uma nova lista file do tipo string que vai armazenar todas as linhas do ficheiro


            foreach (var data in file) //percorre todos os valores na lista file
            {

                string[] entries = data.Split(','); //guarda num array os dados individualmente utilizando a vírgula como referência

                Patient newPatient = new Patient(); //criacao de um novo paciente

                //em cada um destes parâmetros é feito uma transferencia de dados para o newPatient 
                newPatient.First_Name = entries[0];
                newPatient.Last_Name = entries[1];
                newPatient.Region = entries[2];
                newPatient.Age = int.Parse(entries[3]);
                newPatient.Gender = (EGender)Enum.Parse(typeof(EGender),(entries[4]));
                newPatient.IsInfected = Boolean.Parse(entries[5]);
                newPatient.HasSymptoms = Boolean.Parse(entries[6]);
                newPatient.Disease = entries[7];
                newPatient.Disease_Description = entries[8];

                patients_all.Add(newPatient); //Por fim o newPatient é adicionada na lista allPatients
            }
        }


        public static bool AddPatient(Patient patient)
        {
            try
            {
                if (patients_all.Contains(patient)) /*.Contains verifica se a pessoa existe na lista*/
                {
                    return false;
                }

            }
            catch (InsertException e)
            {

                Console.WriteLine($"Error: {e.Message}");
            }
            return true;
        }
        /*Insere nova pessoa*/
        public static void AddPatientSymptons(Patient patient)
        {
            try
            {
                if (patient_symptoms.Contains(patient) == false) /*.Contains verifica se a pessoa existe na lista*/
                {
                    patient_symptoms = patients_all.FindAll(item => item.HasSymptoms == true);

                }
            }
            catch (InsertException e)
            {
                Console.WriteLine($"Error: {e.Message}");
            }
        }

        public static void AddPatientNOSymptons(Patient patient)
        {
            try
            {

                if (patient_NOsymptoms.Contains(patient) == false) /*.Contains verifica se a pessoa existe na lista*/
                {
                    patient_NOsymptoms = patients_all.FindAll(item => item.HasSymptoms == false);
                }
            }
            catch (InsertException e)
            {
                Console.WriteLine($"Error: {e.Message}");
            }
        }
        public static void PrintList_AllPatients()
        {
            Console.WriteLine("\n ------- ALL PATIENTS -------\n");

            foreach (var item in patients_all)
            {
                Console.WriteLine("----- PATIENT INFO -----\n");
                Console.WriteLine($"ID: {item.PersonID}\nFirst Name: {item.First_Name}\nLast Name: {item.Last_Name}\nRegion: {item.Region}\nAge: {item.Age}\nGender: {item.Gender}\nInfected: {item.IsInfected}\nSymptoms: {item.HasSymptoms}\nDisease: {item.Disease}\nDisease Description: {item.Disease_Description}");
                Console.WriteLine("---------------------------------------");
            }
        }

        public static void PrintList_Symptoms()
        {
            Console.WriteLine("\n ------- ALL PATIENTS -------\n");

            foreach (var item in patient_symptoms)
            {
                Console.WriteLine("----- PATIENT INFO -----\n");
                Console.WriteLine($"ID: {item.PersonID}\nFirst Name: {item.First_Name}\nLast Name: {item.Last_Name}\nRegion: {item.Region}\nAge: {item.Age}\nGender: {item.Gender}\nInfected: {item.IsInfected}\nSymptoms: {item.HasSymptoms}\nDisease: {item.Disease}\nDisease Description: {item.Disease_Description}");
                Console.WriteLine("---------------------------------------");
            }
        }

        public static void PrintList_NOSymptoms()
        {
            Console.WriteLine("\n ------- ALL PATIENTS -------\n");

            foreach (var item in patient_NOsymptoms)
            {
                Console.WriteLine("----- PATIENT INFO -----\n");
                Console.WriteLine($"ID: {item.PersonID}\nFirst Name: {item.First_Name}\nLast Name: {item.Last_Name}\nRegion: {item.Region}\nAge: {item.Age}\nGender: {item.Gender}\nInfected: {item.IsInfected}\nSymptoms: {item.HasSymptoms}\nDisease: {item.Disease}\nDisease Description: {item.Disease_Description}");
                Console.WriteLine("---------------------------------------"); 
            }
        }

        public static void PrintList_Filtered()
        {
            foreach (var item in filtered_list)
            {
                Console.WriteLine("----- PATIENT INFO -----\n");
                Console.WriteLine($"ID: {item.PersonID}\nFirst Name: {item.First_Name}\nLast Name: {item.Last_Name}\nRegion: {item.Region}\nAge: {item.Age}\nGender: {item.Gender}\nInfected: {item.IsInfected}\nSymptoms: {item.HasSymptoms}\nDisease: {item.Disease}\nDisease Description: {item.Disease_Description}");
                Console.WriteLine("---------------------------------------");
            }
        }

        public static bool VerifyID_Patients_All(int id) /*Verifica se o ID existe*/
        {
            if (patients_all.Exists(item => item.PersonID == id) == true) 
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        public static int SearchID_Patients_All(int id) /*Encontra a posicao na lista de um certo ID*/
        {
            int save_pos;
            save_pos = patients_all.FindIndex(item => item.PersonID == id); 

            return save_pos;
        }
        public static void Filter_List_By_Infected()
        {
            filtered_list = null; /*Esvaziar a lista sempre que acontece um filtro*/

            filtered_list = patients_all.FindAll(item => item.IsInfected == true);

            if (filtered_list.Count > 0)
            {
                Console.WriteLine("\n ------- INFECTED PATIENTS -------\n");
                PrintList_Filtered();
            }
            else
            {
                Console.WriteLine("No patients matching the criteria were found.");
            }

        }

        public static void Filter_List_By_Age(int age)
        {

            filtered_list = null; /*Esvaziar a lista sempre que acontece um filtro*/

            filtered_list =  patients_all.FindAll(item => item.Age == age && item.IsInfected == true);

            if (filtered_list.Count > 0)
            {
                Console.WriteLine($"\n ------- INFECTED PATIENTS WITH {age} YEARS OLD -------");
                PrintList_Filtered();
            }
            else 
            {
                Console.WriteLine("No patients matching the criteria were found.");
            }

        }

        public static void Filter_List_By_Region(string region)
        {

            filtered_list = null; /*Esvaziar a lista sempre que acontece um filtro*/

            filtered_list = patients_all.FindAll(item => item.Region.ToLower() == region.ToLower() && item.IsInfected == true);


            if (filtered_list.Count > 0 )
            {
                Console.WriteLine($"\n ------- INFECTED PATIENTS IN {region.ToUpper()} -------");
                PrintList_Filtered();
            }
            else
            {
                Console.WriteLine("No patients matching the criteria were found.");
            }

        }
                          
        public static void Filter_List_By_Gender(EGender gender)
        {
            filtered_list = null; /*Esvaziar a lista sempre que acontece um filtro*/

            filtered_list = patients_all.FindAll(item => item.Gender == gender && item.IsInfected == true);

            if (filtered_list.Count > 0)
            {
                Console.WriteLine($"\n ------- {gender.ToString().ToUpper()} INFECTED PATIENTS -------");
                PrintList_Filtered();
            }
            else
            {
                Console.WriteLine("No patients matching the criteria were found.");
            }
        }

        public static void All_Patient_Stats() /*Funcao que da estatisticas sobr todos os pacientes*/
        {
            int infected_total = 0; //Total de infetados
            int patients_total = 0; //Total de pacientes
            int asymptomatic_total = 0; //Total de assintomaticos
            int symptomatic_total = 0; //Total de sintomaticos


            foreach (var item in patients_all)
            {
                patients_total++;
                if (item.IsInfected == true)
                {
                    infected_total++;
                }
                if (item.HasSymptoms == true)
                {
                    symptomatic_total++;
                }
                if (item.HasSymptoms == false)
                {
                    asymptomatic_total++;
                }
            }

            Console.WriteLine("------ STATS -------");
            Console.WriteLine($"Number of patitents: {patients_total}");
            Console.WriteLine($"Number of patients w/ symptoms: {symptomatic_total}");
            Console.WriteLine($"Number of patients w/o symptoms: {asymptomatic_total}");
            Console.WriteLine($"Number of infected patients: {infected_total}");
            Console.WriteLine($"Average of patients w/ symptoms: {Math.Round((double) symptomatic_total / (double) patients_total,2)}");
            Console.WriteLine("---------------------------------------");
        }

       public static void AlterPatientStatusesByID(int id)
        {
            int option;
            bool tryagainAlterPatientStatusesByID = true;

            while (tryagainAlterPatientStatusesByID == true)
            {
                try
                {
                    tryagainAlterPatientStatusesByID = false;
                    Console.WriteLine("What do you want to change?");
                    Console.WriteLine("\n 1 - Symptoms status | 2 - Is Infected status | 0 - Nothing (Exit)\n");
                    option = Convert.ToInt32(Console.ReadLine());

                    #region MUDAR SINTOMAS
                    if (option == 1) // mudar sintomas
                    {
                        foreach (var item in patients_all)
                        {
                            if (item.PersonID == id)
                            {
                                if (item.HasSymptoms == true)
                                {
                                    item.HasSymptoms = false;
                                    Console.WriteLine($"Patient {item.First_Name} {item.Last_Name} (ID: {item.PersonID}) now has no symptoms.\n");
                                }
                                else
                                {
                                    item.HasSymptoms = true;
                                    Console.WriteLine($"Patient {item.First_Name} {item.Last_Name} (ID: {item.PersonID}) now has symptoms.\n");

                                }
                            }
                        }
                    }
                    #endregion

                    #region MUDAR ESTADO INFETADO
                    if (option == 2) // mudar infetado
                    {
                        foreach (var item in patients_all)
                        {
                            if (item.PersonID == id)
                            {
                                if (item.IsInfected == true)
                                {
                                    item.IsInfected = false;
                                    Console.WriteLine($"Patient {item.First_Name} {item.Last_Name} (ID: {item.PersonID}) is now declared cured.\n");
                                }
                                else
                                {
                                    item.IsInfected = true;
                                    Console.WriteLine($"Patient {item.First_Name} {item.Last_Name} (ID: {item.PersonID}) is now declared infected.\n");

                                }
                            }
                        }
                    }
                    #endregion

                    #region exit
                    if (option == 0)
                    {
                        Menu();
                    }
                    #endregion

                }
                catch (InvalidOptionAlterByIDException)
                {
                    tryagainAlterPatientStatusesByID = true;
                    Console.WriteLine("Please enter a valid option\n");
                }
                catch (FormatException)
                {
                    tryagainAlterPatientStatusesByID = true;
                    Console.WriteLine("Please enter a valid option\n");
                }
                catch (Exception e)
                {
                    tryagainAlterPatientStatusesByID = false;
                    Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    Environment.Exit(0);
                }
            }
            
        }


    }
}
