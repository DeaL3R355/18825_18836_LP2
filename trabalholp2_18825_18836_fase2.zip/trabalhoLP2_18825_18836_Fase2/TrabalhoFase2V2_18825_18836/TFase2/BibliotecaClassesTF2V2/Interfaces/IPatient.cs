﻿namespace BibliotecaClassesTF2V2
{
    public interface IPatient : IPerson
    {
        string Blood_Type { get; set; }
    }
}