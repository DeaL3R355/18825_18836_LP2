﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.XPath;

namespace BibliotecaClassesTF2V2
{
    public class Doctor : Person
    {
        #region Atributos

        string[] patientsIDs = new string[3]; //Every doctor will store at max 4 patient IDs

        #endregion

        #region Construtores
        public Doctor()
        {
        }

        public Doctor(int personID, string first_name, string last_name, string region, int age, EGender gender, string[] patientIDs)
        {
            this.patientsIDs = patientIDs;
        }

        #endregion

        #region Propriedades

        public string[] patientIDs
        {
            get { return patientIDs; }
            set { patientIDs = value; }
        }

        #endregion
    }
}
