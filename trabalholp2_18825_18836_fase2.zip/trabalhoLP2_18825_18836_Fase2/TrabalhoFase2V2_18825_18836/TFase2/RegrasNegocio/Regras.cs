﻿using BibliotecaClassesTF2V2; /*Objetos Negocio*/
using Dados;
using Exceptions;
using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace RegrasNegocio
{
    public enum Resposta
    {
        Nao,
        Sim,
    }

    public class Regras
    {
        public Regras()
        {

        }

        /*Metodo da classe intermédia recebe dados da interação*/

        /*Insere nova pessoa*/
        /*Devolve excecao "InsereException"*/

        public static void AskForPatient (Patient p)
        {
            try
            {
                Patients.AskForPatient(p);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static void SaveAll(Patient p)
        {
            try
            {
                Patients.SaveAll(p);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static void LoadAll()
        {
            try
            {
                Patients.LoadAll();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public static bool AddPatient(Patient p)
        {
            /*Aplicar uma regra qualquer de negócio*/

            try
            {
                return Patients.AddPatient(p);
            }

            catch (InsertException e)
            {
                throw e;
            }
        }

        public static void AddPatientSymptoms(Patient p)
        {
           /*Aplicar uma regra qualquer de negócio*/
            
            try
            {
                Patients.AddPatientSymptons(p);
            }
            
            catch (InsertException e)
            {
                throw e;
            }
        }
        public static void AddPatientNOSymptoms(Patient p)
        {
            /*Aplicar uma regra qualquer de negócio*/

            try
            {
                Patients.AddPatientNOSymptons(p);
            }

            catch (InsertException e)
            {
                throw e;
            }
        }

        public static void PrintList_AllPatients()
        {
            try
            {
                Patients.PrintList_AllPatients();

            }
            catch (Exception e)
            {

                throw e;
            }
        }

        public static void PrintList_Symptoms()
        {
            try
            {
                Patients.PrintList_Symptoms();

            }
            catch (Exception e)
            {

                throw e;
            }
        }

        public static void PrintList_NOSymptoms()
        {
            try
            {
                Patients.PrintList_NOSymptoms();

            }
            catch (Exception e)
            {

                throw e;
            }
        }
        public static bool VerifyID_Patients_All(int id)
        {
            try
            {   
                return Patients.VerifyID_Patients_All(id);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error: {e.Message}");
                return false;
            }
        }
        public static int SearchID_Patients_All(int id)
        {
            try
            {
                return Patients.SearchID_Patients_All(id);
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error: {e.Message}");
                Console.WriteLine("XD");
                return 0;
            }
        }
        public static void All_Patient_Stats()
        {
            try
            {
                Patients.All_Patient_Stats();
            }
            catch (Exception e)
            {
                Console.WriteLine($" ERROR: {e.Message}");
                Console.WriteLine("Exiting program");
                Console.ReadKey();
                Environment.Exit(0);
            }
        }
        public static void Filter_List_By_Infected()
        {
            try
            {
                Patients.Filter_List_By_Infected();
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}");
            }
        }
        public static void Filter_List_By_Age(int age)
        {
            try
            {
                Patients.Filter_List_By_Age(age);
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}");
            }
        }
        public static void Filter_List_By_Region(string region)
        {
            try
            {
                Patients.Filter_List_By_Region(region);
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}");
            }
        }

        public static void Filter_List_By_Gender(EGender gender)
        {
            try
            {
                Patients.Filter_List_By_Gender(gender);
            }
            catch (Exception e)
            {
                Console.WriteLine($"{e.Message}");
            }
        }

        public static void Menu()
        {
            try
            {
                Patients.Menu();
            }
            catch (Exception)
            {

                Console.WriteLine("Couldn't handle your error.\nPress any key to exit");
                Console.ReadKey();
                Environment.Exit(0);
            }
        }

        public static void AlterPatientStatusesByID(int id)
        {
            try
            {
                Patients.AlterPatientStatusesByID(id);
            }
            catch (Exception)
            {
                Console.WriteLine("Couldn't handle your error.\nPress any key to exit");
                Console.ReadKey();
                Environment.Exit(0);
            }
        }


    }
}

