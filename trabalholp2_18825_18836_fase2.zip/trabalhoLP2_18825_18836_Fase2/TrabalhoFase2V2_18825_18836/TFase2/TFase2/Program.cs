﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using BibliotecaClassesTF2V2;
using Exceptions;
using RegrasNegocio;
using System.Timers;
using System.ComponentModel.Design;
using Microsoft.SqlServer.Server;

namespace TFase2
{
    class Program
    {
        

        static void Main(string[] args)
        {
            int option = -1;
            bool tryagainMENU = true;
            Console.WriteLine("Gerir pacientes");

            #region PACIENT DATA
            //Patient p1 = new Patient("Carlos", "Martins", "Braga", 19, EGender.MALE, false, false, "B+", "None","None");
            //Patient p2 = new Patient("Ana", "Braga", "Porto", 19, EGender.FEMALE, false, false, "A+", "None", "None");
            //Patient p3 = new Patient("Teresa", "Rocha", "Lisboa", 20, EGender.FEMALE, true, true, "B+", "None", "None");
            //Patient p4 = new Patient("Joao", "Pedro", "Lisboa", 19, EGender.MALE, true, true, "B+", "None", "None");
            #endregion
            Patient p5 = new Patient();
            Regras.LoadAll();

            #region INSERT ALL PATIENTS
            try
            {
                //Regras.AddPatient(p1);
                //Regras.AddPatient(p2);
                //Regras.AddPatient(p3);
                //Regras.AddPatient(p4);
                Regras.AddPatient(p5);

            }
            catch (InsertException e)
            {
                Console.WriteLine($"ERROR: {e.Message}");
            }
            #endregion

            #region INSERT PATIENTS WITH SYMPTOMS
            try //Pegar em todos os pacientes e fazer a verificaçao se tem sintomas ou nao
            {
                //Regras.AddPatientSymptoms(p1);
                //Regras.AddPatientSymptoms(p2);
                //Regras.AddPatientSymptoms(p3);
                //Regras.AddPatientSymptoms(p4);
                Regras.AddPatientSymptoms(p5);

            }
            catch (InsertException e)
            {
                Console.WriteLine($"ERROR: {e.Message}");
            }
            #endregion

            #region INSERT PATIENTS WITH NO SYMPTOMS
            try //Pegar em todos os pacientes e fazer a verificaçao se tem sintomas ou nao
            {
                //Regras.AddPatientNOSymptoms(p1);
                //Regras.AddPatientNOSymptoms(p2);
                //Regras.AddPatientNOSymptoms(p3);
                //Regras.AddPatientNOSymptoms(p4);
                Regras.AddPatientNOSymptoms(p5);

            }
            catch (InsertException e)
            {
                Console.WriteLine($"ERROR: {e.Message}");
            }


            #endregion


            while (tryagainMENU == true)
            {
                try
                {
                    Regras.Menu();
                    while (option != 0)
                    {
                        Console.Write("\nChoose an option: ");
                        option = Convert.ToInt16(Console.ReadLine());

                        switch (option)
                        {
                            case 1:
                                Regras.PrintList_AllPatients();
                                break;
                            case 2:
                                Regras.PrintList_Symptoms();
                                break;
                            case 3:
                                Regras.PrintList_NOSymptoms();
                                break;
                            case 4:
                                Regras.Filter_List_By_Infected();
                                break;
                            case 5:
                                #region Filter By Age
                                int age;
                                bool tryagainOPT5 = true;

                                while (tryagainOPT5 == true)
                                {
                                    try
                                    {
                                        tryagainOPT5 = false;
                                        Console.WriteLine("\nEnter the age that you want to search for: ");
                                        age = Convert.ToInt32(Console.ReadLine());
                                        if (age < 0)
                                        {
                                            throw (new AgeIsNegativeException());
                                        }
                                        Regras.Filter_List_By_Age(age);
                                       
                                    }
                                    catch (AgeIsNegativeException)
                                    {
                                        tryagainOPT5 = true;
                                        Console.WriteLine("\nERROR: Age can not be a negative number. \nPlease enter a valid age.\n");
                                    }
                                    catch (FormatException)
                                    {
                                        tryagainOPT5 = true;
                                        Console.WriteLine("Please enter a valid age");
                                    }
                                    catch (Exception e)
                                    {
                                        tryagainOPT5 = false;
                                        Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                                        Console.WriteLine("Press any key to exit");
                                        Console.ReadKey();
                                        Environment.Exit(0);
                                    }
                                }
                                #endregion
                                break;
                            case 6:
                                #region Filter By Region
                                string region;
                                bool tryagainOPT6 = true;

                                while (tryagainOPT6 == true)
                                {
                                    try
                                    {
                                        tryagainOPT6 = false;
                                        Console.WriteLine("\nEnter the region that you want to search for: ");
                                        region = Console.ReadLine().ToLower();
                                        Regras.Filter_List_By_Region(region);

                                    }
                                    catch (Exception e)
                                    {
                                        tryagainOPT6 = false;
                                        Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                                        Console.WriteLine("Press any key to exit");
                                        Console.ReadKey();
                                        Environment.Exit(0);
                                    }
                                }
                                #endregion
                                break;
                            case 7:
                                #region Filter By Gender
                                string gender_aux;
                                bool tryagainOPT7 = true;

                                while (tryagainOPT7 == true)
                                {
                                    try
                                    {
                                        tryagainOPT7 = false;
                                        Console.WriteLine("\nEnter the gender that you want to search for: ");
                                        gender_aux = Console.ReadLine().ToUpper();
                                        EGender gender = (EGender)Convert.ToInt32(gender_aux); /*Esta me a pedir um int nao sei porque*/
                                        Regras.Filter_List_By_Gender(gender);
                                    }
                                    catch (FormatException)
                                    {
                                        tryagainOPT7 = true;
                                        Console.WriteLine("Please enter a valid gender");
                                    }
                                    catch (Exception e)
                                    {
                                        tryagainOPT7 = false;
                                        Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                                        Console.WriteLine("Press any key to exit");
                                        Console.ReadKey();
                                        Environment.Exit(0);
                                    }
                                }
                                #endregion
                                break;
                            case 8:
                                Regras.All_Patient_Stats();
                                break;
                            case 9:
                                bool tryagainOPT9 = true;
                                int id_case9;
                                while (tryagainOPT9 == true)
                                {
                                    try
                                    {
                                        Console.WriteLine("Enter patient's ID: ");
                                        id_case9 = Convert.ToInt32(Console.ReadLine());
                                        if (Regras.VerifyID_Patients_All(id_case9) == true)
                                        {
                                            Regras.AlterPatientStatusesByID(id_case9);
                                            tryagainOPT9 = false;
                                            Regras.Menu();

                                        }
                                        else
                                        {
                                            Console.WriteLine("ID not found.");
                                            tryagainOPT9 = false;
                                            Regras.Menu();
                                        }

                                    }
                                    catch (FormatException)
                                    {
                                        tryagainOPT9 = true;
                                        Console.WriteLine("Please enter a valid ID");
                                    }
                                    catch (Exception e)
                                    {
                                        tryagainOPT9 = false;
                                        Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                                        Console.WriteLine("Press any key to exit");
                                        Console.ReadKey();
                                        Environment.Exit(0);
                                    }

                                }
                                break;
                            case 10:
                                Regras.AskForPatient(p5);
                                break;
                            case 11:                               
                                Regras.Menu();
                                break;
                            case 0:
                                Environment.Exit(0);
                                break;
                            default:
                                Console.WriteLine("\nInvalid option");
                                break;
                        }
                    }


                }
                catch (FormatException)
                {
                    tryagainMENU = true;
                    Console.WriteLine("Please enter a valid option");
                }
                catch (Exception e)
                {
                    tryagainMENU = false;
                    Console.WriteLine($"Couldn't handle your error. Error: {e.Message}");
                    Console.WriteLine("Press any key to exit");
                    Console.ReadKey();
                    Environment.Exit(0);
                } 
            }



            Console.ReadLine();
        }
    }
}
