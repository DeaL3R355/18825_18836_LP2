﻿namespace BibliotecaClassesTF2V2
{
    public interface IPatient : IPerson
    {
        string Blood_Type { get; set; }
        bool HasSymptoms { get; set; }
        bool IsInfected { get; set; }
    }
}