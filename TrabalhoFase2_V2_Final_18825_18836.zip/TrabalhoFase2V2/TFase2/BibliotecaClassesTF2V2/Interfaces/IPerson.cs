﻿namespace BibliotecaClassesTF2V2
{
    public interface IPerson
    {
        int Age { get; set; }
        string First_Name { get; set; }
        EGender Gender { get; set; }
        string Last_Name { get; set; }
        int PersonID { get; }
        string Region { get; set; }
    }
}