﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaClassesTF2V2
{
    public enum EGender
    {
        MALE = 0,
        FEMALE = 1,
    };

    public class Person : IPerson
    {
        #region Atributos

        private static int countID = 0; //global variable to increment everytime a new patient is created (to have unique ID)

        int personID;
        string first_name;
        string last_name;
        string region;
        int age;
        EGender gender;

        #endregion

        #region Construtores

        public Person()
        {
            countID++;
            personID = countID;
        }

        public Person(string first_name, string last_name, string region, int age, EGender gender)
        {
            countID++;
            personID = countID; 
            this.first_name = first_name;
            this.last_name = last_name;
            this.region = region;
            this.age = age;
            this.gender = gender;
        }

        #endregion

        #region Propriedades

        public int PersonID
        {
            get { return personID; }
        }
        public string First_Name
        {
            get { return first_name; }
            set { first_name = value; }
        }
        public string Last_Name
        {
            get { return last_name; }
            set { last_name = value; }
        }
        public string Region
        {
            get { return region; }
            set { region = value; }
        }
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public EGender Gender
        {
            get { return gender; }
            set { gender = value; }
        }


        #endregion

        #region Metodos


        #endregion


    }
}
