﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaClassesTF2V2
{
    public class Patient : Person, IPatient
    {
        #region Atributos

        bool isInfected;
        bool hasSymptoms;
        string blood_type;
        string disease;
        string disease_description;

        #endregion

        #region Construtores

        public Patient()
        {

        }

        public Patient(string first_name, string last_name, string region, int age, EGender gender, bool isInfected, bool hasSymptoms, string blood_type, string disease, string disease_description) : base(first_name, last_name, region, age, gender)
        {
            this.IsInfected = isInfected;
            this.hasSymptoms = hasSymptoms;
            this.blood_type = blood_type;
            this.disease = disease;
            this.disease_description = disease_description;
        }

        #endregion

        #region Propriedades
        
        public bool IsInfected
        {
            get { return isInfected; }
            set { isInfected = value; }
        }
        public bool HasSymptoms
        {
            get { return hasSymptoms; }
            set { hasSymptoms = value; }
        }
        public string Blood_Type
        {
            get { return blood_type; }
            set { blood_type = value; }
        }
        public string Disease
        {
            get { return disease; }
            set { disease = value; }
        }
        public string Disease_Description
        {
            get { return disease_description; }
            set { disease_description = value; }
        }
        #endregion

        #region Metodos
        
        #endregion
    }
}
