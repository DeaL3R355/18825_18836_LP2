﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class InvalidOptionAlterByIDException : Exception
    {
        public InvalidOptionAlterByIDException(string mesage)
        {

        }
        public InvalidOptionAlterByIDException(int option)
        {
            if (option != 0 || option != 1 || option != 2) // So pode ser uma das 3 opcoes
            {
                throw (new InvalidOptionAlterByIDException("Option not valid"));
            }
        }
    }
}
