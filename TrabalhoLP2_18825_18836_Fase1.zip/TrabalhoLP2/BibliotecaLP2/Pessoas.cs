﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaLP2
{
    public class Pessoas
    {
        #region ATRIBUTOS
        const int MAX = 10; //Vai ser o numero maximo de utentes permitidos

        static Pessoa[] pess;
        static int numPessoas; //Contador de utentes
        #endregion

        #region CONSTRUTORES

        static Pessoas()
        {
            pess = new Pessoa[MAX];
        }

        #endregion

        #region FUNCOES

        public static bool VerificaPessoa(string nome)
        {
            for (int i = 0; i < numPessoas; i++)
            {
                if (pess[i].Nome.CompareTo(nome) == 0)
                {
                    return true;
                }
            }
            return false; //Tem que ser fora, porque ao percorrer os nomes todos,
                          //vao existir nomes que nao sao o que queremos, ou seja
                          //precisamos do false fora do ciclo
        }


        public static int InserePessoa(Pessoa p) //Adicionar utente à lista de pessoas
        {
            if (numPessoas >= MAX) //Se for maior ou igual é porque nao sao permitidos mais utentes
            {
                Console.WriteLine("A lista esta cheia");
                return 0;
            }

            pess[numPessoas++] = p;
            return 1;
        }

        public static void MudaEstadoInfetado(Pessoa[] pess)
        {
            int auxID =-1, i;

            while (auxID != 0)
            {
                Console.WriteLine("Insira o ID que quer mudar: (Insira 0 para parar de alterar)");
                auxID = Convert.ToInt16(Console.ReadLine());

                for (i = 0; i < numPessoas; i++)
                {
                    if (auxID == pess[i].Identificacao)
                    {
                        if (pess[i].Infetado == true)
                        {
                            pess[i].Infetado = false;
                        }

                        else
                        {
                            pess[i].Infetado = true;
                        }
                    }
                }
            }
            
        }
        #endregion

        public static void ContabilizarCasosTotais(Pessoa[] pess)
        {
            int contador = 0;

            for (int i = 0; i < numPessoas; i++)
            {
                if (pess[i].Infetado == true)
                {
                    contador++;
                }
            }

            Console.WriteLine("\nO total de infetados e : {0}", contador);
        }
        public static void ContabilizarCasosRegiao(Pessoa[] pess)
        {
            int contador = 0;
            string gRegiao;

            Console.Write("\nRegioes encontradas: ");
            for (int i = 0; i < numPessoas; i++)
            {
                Console.Write("{0} | ", pess[i].Regiao);
            }

            Console.WriteLine("\nIntroduza a regiao a procurar: ");
            gRegiao = Console.ReadLine().ToLower();

            for (int i = 0; i < numPessoas; i++)
            {
                if (gRegiao == pess[i].Regiao.ToLower() && pess[i].Infetado == true)
                {
                    contador++;
                }
            }

            Console.WriteLine("\nA regiao {0} tem {1} pessoas infetadas", gRegiao, contador);
        }

        public static void ContabilizarCasosIdades(Pessoa[] pess)
        {
            int gIdade, contador = 0;

            Console.WriteLine("Introduza a idade a pesquisar: ");
            gIdade = Convert.ToInt16(Console.ReadLine());

            for (int i = 0; i < numPessoas; i++)
            {
                if (gIdade == pess[i].Idade && pess[i].Infetado == true)
                {
                    contador++;
                }
            }

            Console.WriteLine("Existem {0} casos de pessoas com {1} anos", contador, gIdade);
        }

        public static void ContabilizarCasosGenero(Pessoa[] pess)
        {
            int contador = 0;
            string gGenero;

            Console.WriteLine("Introduza o sexo a procurar: (Masculino | Feminino)");
            gGenero = Console.ReadLine().ToLower();

            for (int i = 0; i < numPessoas; i++)
            {
                if (gGenero == pess[i].Genero.ToLower() && pess[i].Infetado == true)
                {
                    contador++;
                }
            }
            Console.WriteLine("Existem {0} casos do genero {1}", contador, gGenero);


        }

       public static void Menu()
       {
            Console.WriteLine("--------------------------- MENU --------------------------- ");
            Console.WriteLine("1 - Imprimir pessoas");
            Console.WriteLine("2 - Alterar estado de infetado");
            Console.WriteLine("3 - Contabilizar casos totais");
            Console.WriteLine("4 - Contabilizar casos por regiao");
            Console.WriteLine("5 - Contabilizar casos por idade");
            Console.WriteLine("6 - Contabilizar casos por sexo");
            Console.WriteLine("0 - Sair");

       }

    }
}

