﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BibliotecaLP2;

namespace TrabalhoLP2
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX = 10;
            int numPessoas = 0;
            Pessoa[] pess = new Pessoa[MAX];

            Pessoa p1 = new Pessoa("Carlos", "Braga", "Masculino", 19, true);
            Pessoa p2 = new Pessoa("Cristiana", "Toronto", "Feminino", 19, false);
            Pessoa p3 = new Pessoa("Raquel", "Braga", "Feminino", 19, false);
            Pessoa p4 = new Pessoa("Ana", "Braga", "Feminino", 19, false);


            #region Registar as pessoas
            if (Pessoas.InserePessoa(p1) == 1)
            {
                pess[numPessoas] = p1;
                numPessoas++;
            }

            if (Pessoas.InserePessoa(p2) == 1)
            {
                pess[numPessoas] = p2;
                numPessoas++;
            }

            if (Pessoas.InserePessoa(p3) == 1)
            {
                pess[numPessoas] = p3;
                numPessoas++;
            }

            if (Pessoas.InserePessoa(p4) == 1)
            {
                pess[numPessoas] = p4;
                numPessoas++;
            }
            #endregion           

            #region MENU

            Pessoas.Menu();
            
            int opcao =-1;

            while (opcao != 0)
            {
                Console.Write("\nIntroduza a opcao: ");
                opcao = Convert.ToInt16(Console.ReadLine());

                switch (opcao)
                {
                    case 1:
                        #region Imprimir as pessoas

                Console.WriteLine("\nAs pessoas registadas são");
                for (int i = 0; i < numPessoas; i++)
                {
                    Console.WriteLine("ID {0} | Nome {5} | Regiao {1} | Genero {2} | Idade {3} | Infetado: {4}", pess[i].Identificacao, 
                                                                                                      pess[i].Regiao, 
                                                                                                      pess[i].Genero, 
                                                                                                      pess[i].Idade, 
                                                                                                      pess[i].Infetado,
                                                                                                      pess[i].Nome);
                }

            #endregion
                        break;
                    case 2:
                        Pessoas.MudaEstadoInfetado(pess);
                        Console.WriteLine("\n");
                        Pessoas.Menu();
                        break;
                    case 3:
                        Pessoas.ContabilizarCasosTotais(pess);
                        Console.WriteLine("\n");
                        Pessoas.Menu();
                        break;
                    case 4:
                        Pessoas.ContabilizarCasosRegiao(pess);
                        Console.WriteLine("\n");
                        Pessoas.Menu();
                        break;
                    case 5:
                        Pessoas.ContabilizarCasosIdades(pess);
                        Console.WriteLine("\n");
                        Pessoas.Menu();
                        break;
                    case 6:
                        Pessoas.ContabilizarCasosGenero(pess);
                        Console.WriteLine("\n");
                        Pessoas.Menu();
                        break;
                    case 0:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("\nOpcao invalida");
                        break;
                }
            }
            
            #endregion



            Console.ReadLine();


        }
    }
}
